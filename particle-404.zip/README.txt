A Pen created at CodePen.io. You can find this one at https://codepen.io/richardwestenra/pen/rZmERo.

 Constantly-shifting network of particles spelling out the number 404. Based on my friend Ottis' Canvas Particles demo: https://github.com/ottis/canvas-particles